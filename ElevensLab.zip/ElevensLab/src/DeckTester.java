/**
 * This is a class that tests the Deck class.
 */
public class DeckTester {

	/**
	 * The main method in this class checks the Deck operations for consistency.
	 *	@param args is not used.
	 */
	public static void main(String[] args) {
		//activity 3
		String[] ranks1 = {"K", "A", "Q", "2", "J", "3", "10", "4", "9", "5", "8", "6", "7"};
		String[] suits1 = {"Spades", "Diamonds", "Clubs", "Hearts", "Spades", "Diamonds", "Clubs",
				"Hearts", "Spades", "Diamonds", "Clubs", "Hearts", "Spades"};
		int[] values1 = {13, 1, 12, 2, 11, 3, 10, 4, 9, 5, 8, 6, 7};
		
		String[] ranks2 = {"K", "K", "J", "7", "A", "4", "6", "7", "6", "5"};
		String[] suits2 = {"Spades", "Diamonds", "Spades", "Hearts", "Hearts", "Diamonds", "Clubs",
				"Clubs", "Spades", "Diamonds"};
		int[] values2 = {13, 13, 11, 7, 1, 4, 6, 7, 6, 5};
		
		String[] ranks3 = {};
		String[] suits3 = {};
		int[] values3 = {};
		
		Deck deck1 = new Deck(ranks1, suits1, values1);
		Deck deck2 = new Deck(ranks2, suits2, values2);
		Deck deck3 = new Deck(ranks3, suits3, values3);
		
		System.out.println(deck1.size());
		System.out.println(deck2.size());
		System.out.println(deck3.size());
		
		System.out.println(deck1.isEmpty());
		System.out.println(deck2.isEmpty());
		System.out.println(deck3.isEmpty());
		
		System.out.println(deck1.deal());
		System.out.println(deck1.deal());
		System.out.println(deck2.deal());
		System.out.println(deck2.deal());
		System.out.println(deck2.deal());
		System.out.println(deck3.deal());
		
		System.out.println(deck1.toString());
		System.out.println(deck2.toString());
		System.out.println(deck3.toString());
		
		//activity 4
		String[] rank = {"K", "Q", "J", "10", "9", "8", "7", "6", "5", "4", "3", "2", "A",
				"K", "Q", "J", "10", "9", "8", "7", "6", "5", "4", "3", "2", "A",
				"K", "Q", "J", "10", "9", "8", "7", "6", "5", "4", "3", "2", "A",
				"K", "Q", "J", "10", "9", "8", "7", "6", "5", "4", "3", "2", "A"};
		String[] suit = {"Spades", "Spades",  "Spades",  "Spades",  "Spades",  "Spades",  "Spades",  "Spades",  "Spades",  "Spades", "Spades",  "Spades",  "Spades", 
				"Diamonds", "Diamonds", "Diamonds", "Diamonds", "Diamonds", "Diamonds", "Diamonds", "Diamonds", "Diamonds", "Diamonds", "Diamonds", "Diamonds", "Diamonds", 
				"Hearts", "Hearts", "Hearts", "Hearts", "Hearts", "Hearts", "Hearts", "Hearts", "Hearts", "Hearts", "Hearts", "Hearts", "Hearts", 
				"Clubs", "Clubs", "Clubs", "Clubs", "Clubs", "Clubs", "Clubs", "Clubs", "Clubs", "Clubs", "Clubs", "Clubs", "Clubs"};
		int[] value = {13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 
				13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 
				13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 
				13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, };
		Deck deck = new Deck(rank, suit, value);
		System.out.println(deck.toString());
		deck.shuffle();
		System.out.println(deck.toString());
	}
}